package com.example.sjs_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
